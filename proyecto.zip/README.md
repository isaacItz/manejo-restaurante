Rasos para ejecutar el programa:

Requisitos para ejecutar el programa:
1.- contar con JRE version mayor o igual a 1.8
1.- dar doble click al archivo ejecutable.jar
